package com.mcr.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mcr.qa.base.TestBase;
import com.mcr.qa.pages.ConvertPage;
import com.mcr.qa.pages.HomePage;
import com.mcr.qa.util.TestUtil;

public class HomePageTest extends TestBase {
	HomePage homePage;
	ConvertPage convertPage;
	String sheetName= "values"; 
	
	public HomePageTest() {
		
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		 homePage = new HomePage();
		
	}
	
	@DataProvider
	public Object[][] getMcrTestData() {
		
		Object data[][]=TestUtil.getTestData(sheetName);
		return data;		
	}
	
	
	@Test(dataProvider="getMcrTestData")
	public void currencyConvertTest(String euro) {
		
		homePage.currencyConvert(euro);
		Assert.assertTrue(homePage.conversionVerify());
		
	}
	

	
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}

}
