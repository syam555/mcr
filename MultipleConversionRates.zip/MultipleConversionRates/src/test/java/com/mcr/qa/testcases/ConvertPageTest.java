package com.mcr.qa.testcases;

import static org.testng.Assert.assertTrue;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.mcr.qa.base.TestBase;
import com.mcr.qa.pages.ConvertPage;
import com.mcr.qa.pages.HomePage;


public class ConvertPageTest extends TestBase {
  HomePage homePage;
  ConvertPage convertPage;
	public ConvertPageTest() {
		
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		 homePage = new HomePage();
		 //convertPage=homePage.currencyConvert(euro);
		
	}
	
	@Test
	public void conversionVerifyTest()
	{
		Assert.assertTrue(convertPage.conversionVerify());
	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}

}
