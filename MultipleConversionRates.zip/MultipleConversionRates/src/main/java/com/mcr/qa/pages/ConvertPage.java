package com.mcr.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.mcr.qa.base.TestBase;

public class ConvertPage extends TestBase {
	
	@FindBy(xpath="//span[@class='converterresult-toAmount']")
	WebElement converterResultToAmount;
	@FindBy(xpath="//span[@class='converterresult-fromAmount'")
	WebElement converterResultFromAmount;
	@FindBy(xpath="//span[contains(@class,'converterresult-unitConversion sc-EHOje lkcPkj')]")
	WebElement unitConversion;
	
	public ConvertPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public boolean conversionVerify() {
		
		/*String conversionFactor=unitConversion.toString();
		conversionFactor.substring(5, 16);
		String fromAmount= converterResultFromAmount.toString();*/
		
	  return true;
	}
}
