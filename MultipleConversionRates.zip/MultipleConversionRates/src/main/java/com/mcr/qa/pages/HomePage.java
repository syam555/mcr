package com.mcr.qa.pages;

import java.math.BigDecimal;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mcr.qa.base.TestBase;

public class HomePage extends TestBase {

	 
	//PageFactory -OR
	
	@FindBy(xpath="//input[@id='amount']")
	WebElement AmountToConvert;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement SubmitButton;
	@FindBy(xpath="//span[@class='converterresult-toAmount']")
	WebElement converterResultToAmount;
	@FindBy(xpath="//span[@class='converterresult-fromAmount']")
	WebElement converterResultFromAmount;
	/*@FindBy(xpath="//span[contains(@class,'converterresult-unitConversion sc-EHOje lkcPkj')]")
	WebElement unitConversion;*/
	
	public HomePage()
	{
		PageFactory.initElements(driver,this);
		
	}
	
	public void currencyConvert(String valueToConvert)
	{
		
		
		//ToCurrency.click();
		
		 /*wait.until(ExpectedConditions
		        .elementToBeClickable(
		                By.xpath("//button[@class='privacy-basic-button privacy-basic-button-submit']"))).click();*/
		 driver.findElement(By.xpath("//button[@class='privacy-basic-button privacy-basic-button-submit']")).click();
		 driver.findElement(By.xpath("//input[@id='amount']")).sendKeys(valueToConvert);
		  
		 
		 
		//AmountToConvert.sendKeys(String.valueOf(ValueToConvert));
		/*wait.until(ExpectedConditions
		        .elementToBeClickable(
		                By.xpath("//div[contains(@class,'css-1wy0on6 converterform-dropdown__indicators')]")))
		        .click();*/
		// driver.findElement(By.xpath("//div[contains(@class,'css-1wy0on6 converterform-dropdown__indicators')]")).sendKeys(Keys.ENTER);
		/*wait.until(ExpectedConditions
		        .elementToBeClickable(
		                By.xpath("//span[contains(text(),'"+FromCurrencyType+"')]")))
		        .click();*/
		WebElement webElementFrom=driver.findElement(By.xpath("//div[contains(@class,'css-1rtrksz converterform-dropdown__value-container converterform-dropdown__value-container--has-value')]"));
		webElementFrom.click();
		webElementFrom.sendKeys(FromCurrencyType);
		webElementFrom.sendKeys(Keys.TAB);
		webElementFrom.sendKeys(Keys.TAB);
		driver.findElement(By.xpath("//button[@aria-label='Invert currencies']")).sendKeys(Keys.TAB);
		WebElement webElementTo=driver.findElement(By.xpath("//div[contains(@class,'css-1rtrksz converterform-dropdown__value-container converterform-dropdown__value-container--has-value')]"));
		webElementTo.sendKeys(ToCurrencyType);
		webElementTo.sendKeys(Keys.TAB);
		webElementTo.sendKeys(Keys.TAB);
		/*wait.until(ExpectedConditions
		        .elementToBeClickable(
		                By.xpath("(//div[contains(@class,'css-1wy0on6 converterform-dropdown__indicators')])[2]")))
		        .click();
		wait.until(ExpectedConditions
		        .elementToBeClickable(
		                By.xpath("//span[contains(text(),'"+ToCurrencyType+"')]")))
		        .click();
		
		wait.until(ExpectedConditions
		        .elementToBeClickable(
		                By.xpath("//button[@type='submit']")))
		        .click();*/
		//driver.findElement(By.xpath("//input[@id='amount']")).sendKeys(valueToConvert);
		//AmountToConvert.sendKeys(String.valueOf(ValueToConvert));
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		//SubmitButton.click();
		
	}
    public boolean conversionVerify() {
		
		String toAmount=converterResultToAmount.toString();
		String fromAmount= converterResultFromAmount.toString();
		BigDecimal temp = new BigDecimal(fromAmount );
		BigDecimal total = temp.multiply( new BigDecimal(ConversionFactor) );
				
		if(toAmount.equals(total.toString()))
		{	
	  return true;
		}
		else
		{
			return false;
		}
    }
}
