package com.mcr.qa.pages;

import java.math.BigDecimal;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mcr.qa.base.TestBase;

public class HomePage extends TestBase {

	static By amount;
	static By fromCurrency;
	static By toCurrency;
	static By subitButton;
	static By coversionRate;
	static By convertedValue;
	
	
	public HomePage()
	{
		
		amount=By.id("amount");
		fromCurrency=By.id("from");
		toCurrency=By.id("to");
		convertedValue=By.id("main-heading");
		coversionRate=By.xpath("//span[contains(@class,'converterresult-unitConversion')]");
		subitButton=By.xpath("//button[@type='submit']");
	}
	
	public void currencyConvert(String valueToConvert)
	{
		driver.findElement(amount).sendKeys(valueToConvert);
		driver.findElement(fromCurrency).sendKeys(FromCurrencyType);
		driver.findElement(fromCurrency).sendKeys(Keys.ENTER);
		driver.findElement(toCurrency).sendKeys(ToCurrencyType);
		driver.findElement(toCurrency).sendKeys(Keys.ENTER);
		driver.findElement(subitButton).click();
		
		
		
		
		 wait.until(ExpectedConditions
		        .elementToBeClickable(
		                By.xpath("//button[@class='privacy-basic-button privacy-basic-button-submit']"))).click();
		
		
	}
    public String conversionVerify() {
    	String Value;
    	String ConversionRate = null;
    	List <WebElement> elements;
    	Value=driver.findElement(convertedValue).getText();
    	elements=driver.findElements(coversionRate);
    	for(WebElement element:elements)
    	ConversionRate=element.getText();
    	
		return ConversionRate; 
    }
}
