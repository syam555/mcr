package com.mcr.qa.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.mcr.qa.base.TestBase;

public class HomePage extends TestBase {

	//PageFactory -OR
	@FindBy(xpath="//div[contains(@class,'css-1wy0on6 converterform-dropdown__indicators')]")
	WebElement FromCurrency;
	@FindBy(xpath="//div[contains(@class,'css-1wy0on6 converterform-dropdown__indicators')]s")
	WebElement ToCurrency;
	
	@FindBy(xpath="//input[@id='amount']")
	WebElement AmountToConvert;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement SubmitButton;
	@FindBy(xpath="//span[@class='converterresult-toAmount']")
	WebElement converterResultToAmount;
	@FindBy(xpath="//span[@class='converterresult-fromAmount'")
	WebElement converterResultFromAmount;
	@FindBy(xpath="//span[contains(@class,'converterresult-unitConversion sc-EHOje lkcPkj')]")
	WebElement unitConversion;
	
	public HomePage()
	{
		PageFactory.initElements(driver,this);
	}
	
	public void currencyConvert(String ValueToConvert)
	{
		
		AmountToConvert.sendKeys(String.valueOf(ValueToConvert));
		FromCurrency.sendKeys("EURO");
		FromCurrency.sendKeys(Keys.ENTER);
		//ToCurrency.click();
		SubmitButton.click();
		
		
	}
    public boolean conversionVerify() {
		
		/*String conversionFactor=unitConversion.toString();
		conversionFactor.substring(5, 16);
		String fromAmount= converterResultFromAmount.toString();*/
		
	  return true;
    }
}
